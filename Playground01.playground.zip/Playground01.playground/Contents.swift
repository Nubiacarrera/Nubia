import UIKit//Nubia L. Carrera Manquera #13610639


var v1 = "Esto es Swift"//asignación del texto esto es Swift a la variable v1

let c1 = 4 //asignación del número 4 a la constante c1

var cadena:String = String()//asignación formal de un tipo de dato String

cadena = "Hola mundo " + v1

print("El contenido es: (cadena)")//salida a consola
print("El valor de constante es:(c1)")//salida a consola
                    
